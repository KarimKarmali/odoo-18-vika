Your preferred way to install addons will work with MIS Builder.

An easy way to install it with all its dependencies is using pip:

- `pip install --pre odoo12-addon-mis_builder`
- then restart Odoo, update the addons list in your database, and
  install the MIS Builder application.
